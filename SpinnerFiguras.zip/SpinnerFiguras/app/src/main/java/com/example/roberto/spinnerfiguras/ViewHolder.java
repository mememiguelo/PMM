package com.example.roberto.spinnerfiguras;

import android.widget.TextView;
/**
 * Created by Miguel on 03/01/2015.
 */

public class ViewHolder {
    TextView tipo;
}