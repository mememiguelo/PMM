package com.example.roberto.spinnerfiguras;

/**
 * Created by Miguel on 03/01/2015.
 */

public  class Figuras {
    protected String tipo;


    public Figuras(String t) {
        tipo = t;

    }

    public String getTipo() {

        return tipo;
    }

}